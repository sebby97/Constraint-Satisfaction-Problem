
***Execution Instructions***



In order to run the file you must provide two parameters:

Input CSV file

Output XML file destination

commandline prompt:

python CSP_Solver.py inputFile.csv outputFile.xml








***If you're bored read this***



SEBASTIAN LACKI

Hey Rick and Kris hope all is well!

Enjoy your easter, or hope your easter was fantastic (if you're grading this after) 

P.S. Please give me an A

sincerely,

A college student whos just trying to find his way... 
